<?php

$name=$_POST['b_name'];
$ad1=$_POST['ad1'];
$ad2=$_POST['ad2'];
$city=$_POST['city'];
$pincode=$_POST['pcode'];
$phone=$_POST['pno'];
$mail=$_POST['mail'];
$pwd=$_POST['pwd'];
$desc=$_POST['desc'];

?>